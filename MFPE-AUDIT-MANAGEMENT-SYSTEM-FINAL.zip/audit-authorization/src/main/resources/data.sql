INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (1, 'Shubham Bhatnagar', 'sb', 'sb000', 'Project-1');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (2, 'Rahul Tomar', 'rt', 'rt000', 'Project-2');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (3, 'Sakshi Labhe', 'sl', 'sl000', 'Project-3');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (4, 'Vemana Venkatesh', 'vv', 'vv000', 'Project-4');
INSERT INTO project_manager_details(id, name, username, password, project_name) VALUES (5, 'Amit Jadhav', 'aj', 'aj000', 'Project-5');