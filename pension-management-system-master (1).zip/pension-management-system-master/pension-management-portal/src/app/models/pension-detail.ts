export class PensionDetail {
    constructor(
        public name: String,
        public dateOfBirth: Date,
        public pan: String,
        public pensionType: String,
        public pensionAmount: number
    ) { }
}        

// private String name;
// private String aadhaarNumber;
// private Date dateOfBirth;
// private String pan;
// private double salary;
// private double allowance;
// private String pensionType;
// private long accountNumber;
// private BankDetails bank;





























