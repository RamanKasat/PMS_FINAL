import { ProcessPensionResponse } from './process-pension-response';

describe('ProcessPensionResponse', () => {
  it('should create an instance', () => {
    expect(new ProcessPensionResponse(21)).toBeTruthy();
  });
});
