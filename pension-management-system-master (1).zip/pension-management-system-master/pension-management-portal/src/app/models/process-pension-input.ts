export class ProcessPensionInput {

    constructor(
        public aadhaarNumber: String,
    ) { }
}
