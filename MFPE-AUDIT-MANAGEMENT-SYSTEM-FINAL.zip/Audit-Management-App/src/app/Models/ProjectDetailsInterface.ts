export interface ProjectDetailsInterface{
    name : string,
    projectName : string,
    valid : boolean
}