export class BankDetails {
    constructor(
        public bankName: String,
        public bankType: String,
        public accountNumber: number
    ) { }
}